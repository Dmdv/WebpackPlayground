const config = {
  entry: {},
  output: {},
  devtool: 'source-map',
  module: {},
  resolve: {}
};

module.exports = config;
