require('../style/stylus/main.styl');
console.log('hello world');
